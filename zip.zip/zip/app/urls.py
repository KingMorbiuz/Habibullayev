from django.urls import path
from .views import *
urlpatterns = [
    path("users/", UserListView.as_view()),
    path("users/<int:pk>/", UserDetailView.as_view()),
    path("get_me/", GetMe.as_view()),
    path('api/task/',TaskAPIView.as_view()),
    path('api/task/<int:pk>/', TaskDetailAPIView.as_view()),
    path('api/clients/', ClientAPIView.as_view()),
    path('api/clients/<int:pk>/', ClientDetailAPIView.as_view() ),
    
]