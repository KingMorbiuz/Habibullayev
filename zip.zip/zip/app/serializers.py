from.models import Client,Task
from rest_framework import serializers
class ClientSerializers(serializers.ModelSerializer):
    class Meta:
        model = Client
        fields = '__all__' 

class TaskSerializers(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'