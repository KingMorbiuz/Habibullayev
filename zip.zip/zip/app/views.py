from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from .models import Task
from .serializers import TaskSerializers, ClientSerializers
from rest_framework.views import APIView
import app.models as models
import json
import app.serializers as sers

class UserListView(APIView):
    def get(self, request):
        users = list(models.User.objects.values())
        return Response(users, safe=False)

    def post(self, request):
        data = json.loads(request.body)
        password = data.pop("password")
        user = models.User.objects.create(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=data["email"]
        )
        user.set_password(password)
        user.save()
        return Response({"message": "Yangi xodim qo'shildi", "user_id": user.id}, status=201)

class UserDetailView(APIView):
    def get(self, request, id):
        try:
            user = models.User.objects.get(id=id)
            return Response({"id": user.id, "first_name": user.first_name, "last_name": user.last_name, "email": user.email})
        except models.User.DoesNotExist:
            return Response({"error": "User topilmadi"}, status=404)
        
class GetMe(APIView):
    def get(self,request):
        user = request.user
        ser = sers.UserSerializers(user)
        return Response(ser.data)
      
class ClientAPIView(APIView):
    def get(sels, request):
        if request.user.is_manger:
            clients = models.Client.objects.all()
            ser = sers.ClientSerializer(clients, many=True)
            return Response(ser.data) 
    
    def post(self, request):
        ser = sers.ClientSerializer(data=request.data)
        if ser.is_valid():
            ser.save()
            return Response(ser.data)
        return Response(ser.errors)
    
class ClientDetailAPIView(APIView):
    def get(self, request, pk):
        client = models.Client.object.get(id=pk)
        ser = sers.ClientSerializer(client)
        return Response (ser.data)
    
    def patch(self, request, pk):
        client = models.Clientobjects.get(id=pk)
        updated = ClientSerializers(data=request.data, intanse=client)

    def delete(self, request, pk):
        client = models.Client.objects.get(id=pk)
        client.delete()
        return Response({'messeges':'deleted'})   


# Create your views here.
class TaskAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        if request.user.is_manager:
            tasks = Task.objects.all()
            ser = TaskSerializers(tasks, many=True)
            return Response(ser.data)
        else:
            tasks = Task.objects.filter(assigned_to=request.user)
            ser = TaskSerializers(tasks, many=True)
            return Response(ser.data)
        
    def post(self, request):
        if request.user.is_manager:
            task = TaskSerializers(data=request.data)
            if task.is_valid():
                task.save()
                return Response(task.data)
            return Response(task.errors)
        return Response({'message':'not allowed'})
    

class TaskDetailAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request, pk):
        task = Task.objects.get(id=pk)
        ser = TaskSerializers(task)
        return Response(ser.data)
    
    def patch(self, request, pk):
        task = Task.objects.get(id=pk)
        if request.user == task.assigned_to:
            updated = TaskSerializers(data=request.data, instance=task, partial=True)
            if updated.is_valid():
                updated.save()
                return Response(updated.data)
            return Response(updated.errors)
        return Response({'message':'not allowed'})
    
    def delete(self, request, pk):
        task = Task.objects.get(id=pk)
        task.delete()
        return Response({'message':'deleted'})
    
class ClinetAPIView(APIView):
    def get(self, request ):
        if request.user.is_manager :
            client = models.Client.object.all()
            ser = sers.ClientSerializers(client, many = True)
            return Response (ser.data)
        

    def post(self, request ):
        if request.user.is_manger :
            client = sers.ClientSerializers(data = request.data)
            if client.is_valid():
                client.save()
            return Response(client.data)


class ClientDetailAPIView(APIView):
    def get(self, request, pk):
        task = Task.objects.get(id=pk)
        ser = ClientSerializers(task)
        return Response(ser.data)
    
    def patch(self, request, pk):
        task = Task.objects.get(id=pk)
        updated = TaskSerializers(data = request.data, isinstance = task, partial = True )
        if task.is_valid():
            updated.save()
            return Response(updated.data)
        
    def delete(self, request, pk):
        task = Task.objects.get(id=pk)
        task.delete()
        return Response({'messages'})
        
