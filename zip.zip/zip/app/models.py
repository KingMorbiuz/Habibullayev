from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.
class CustomUser(AbstractUser):
    is_manager = models.BooleanField(default=False)

class Client(models.Model):
    name = models.CharField
    email = models.EmailField
    phone = models.CharField
    adress = models.TextField
    created_by = models.ForeignKey (CustomUser, on_delete=models.SET_NULL, null=True)

class Task(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    assigned_to = models.ForeignKey(CustomUser,on_delete=models.SET_NULL, null=True, related_name="assigned_to")
    created_by = models.ForeignKey(CustomUser,on_delete=models.SET_NULL, null=True, related_name="created_by") 
    client = models.ForeignKey(Client,on_delete=models.SET_NULL, null=True, related_name="Client")
    status = models.CharField(max_length=255, choices=[(1,"New"), (2, "Pending"), (3, "Complited")]) 
    deadline = models.DateField()
